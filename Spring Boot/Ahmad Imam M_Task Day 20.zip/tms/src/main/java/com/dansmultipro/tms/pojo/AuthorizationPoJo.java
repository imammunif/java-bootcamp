package com.dansmultipro.tms.pojo;

public class AuthorizationPoJo {
    private String id;

    public AuthorizationPoJo(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

}
