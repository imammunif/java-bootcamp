package com.dansmultipro.tms.exception;

public class DataMissMatchException extends RuntimeException {

    public DataMissMatchException(String message) {
        super(message);
    }

}
