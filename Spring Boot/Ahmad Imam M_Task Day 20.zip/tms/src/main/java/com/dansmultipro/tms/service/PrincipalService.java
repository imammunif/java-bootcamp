package com.dansmultipro.tms.service;

import com.dansmultipro.tms.pojo.AuthorizationPoJo;

public interface PrincipalService {

    AuthorizationPoJo getPrincipal();

}
